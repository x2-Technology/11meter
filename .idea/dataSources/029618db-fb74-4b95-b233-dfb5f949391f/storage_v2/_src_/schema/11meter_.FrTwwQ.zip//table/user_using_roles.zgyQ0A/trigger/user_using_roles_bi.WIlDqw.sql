create definer = x2@`%` trigger user_using_roles_bi
  before INSERT
  on user_using_roles
  for each row
begin

    SET NEW.created_at = NOW();

    IF(NEW.team IS NULL) THEN
      SET NEW.team = '[]';
    end if;
    IF(NEW.team_group IS NULL) THEN
      SET NEW.team_group = '[]';
    end if;

    IF(NEW.team_dfb_name IS NULL) THEN
      SET NEW.team_dfb_name = '[]';
    end if;

    IF(NEW.team_dfb_link IS NULL) THEN
      SET NEW.team_dfb_link = '[]';
    end if;
    IF(NEW._code IS NULL) THEN
      SET NEW._code = '[]';
    end if;

  end;

