create definer = x2@`%` trigger new_created_at
  before INSERT
  on messages
  for each row
  SET NEW.created_at=NOW();

