create definer = x2@`%` trigger trigger_club_managers_bi
  before INSERT
  on club_managers
  for each row
BEGIN
    SET NEW.created_at=NOW();
  end;

