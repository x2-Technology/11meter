create definer = x2@`%` trigger delete_denied_for_first_record
  before DELETE
  on clubs
  for each row
BEGIN
IF (OLD.id=1 ) THEN
SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'Delete operation denied for1 Record'; 
END IF;
END;

