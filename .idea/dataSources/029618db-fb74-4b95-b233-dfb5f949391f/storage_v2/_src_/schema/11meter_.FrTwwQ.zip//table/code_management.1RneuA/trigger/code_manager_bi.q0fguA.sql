create definer = x2@`%` trigger code_manager_bi
  before INSERT
  on code_management
  for each row
begin
    SET NEW.created_at=NOW();
  end;

