create definer = x2@`%` trigger trigger_ads_groups_bi
  before INSERT
  on ads
  for each row
BEGIN
    SET NEW.created_at=NOW();
  end;

