create definer = x2@`%` trigger trigger_ad_partners_discussion_sender_send_at_bi
  before INSERT
  on ad_partners_discussion
  for each row
BEGIN
    SET NEW.sender_send_at = NOW();
  end;

