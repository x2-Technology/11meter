create definer = x2@`%` trigger user_menu_b_delete
  before DELETE
  on user_menu
  for each row
  IF ( OLD.sample = 1 ) THEN
SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'Sample menu is Protected can not delete';  
END IF;

