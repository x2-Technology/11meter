create definer = x2@`%` trigger fulldate_trigger_ifbk
  before UPDATE
  on termine
  for each row
  SET NEW.fulldate = CONCAT(NEW.datum, " ", NEW.treff);

