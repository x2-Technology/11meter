create definer = x2@`%` trigger user_using_roles_bd
  after DELETE
  on user_using_roles
  for each row
BEGIN
      #Process if role equals to Club Admin
      UPDATE clubs SET register_id=NULL WHERE register_id=OLD.user_id AND OLD.role_id=29;
      DELETE FROM club_managers WHERE register_id=OLD.user_id AND manager_role=1;
  end;

