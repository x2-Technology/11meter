create definer = x2@`%` trigger module_packet_bi
  before INSERT
  on module_packets
  for each row
  SET NEW.created_at = NOW();

