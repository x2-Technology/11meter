create definer = x2@`%` trigger module_manager_bi
  before INSERT
  on module_manager
  for each row
  SET NEW.created_at = NOW();

