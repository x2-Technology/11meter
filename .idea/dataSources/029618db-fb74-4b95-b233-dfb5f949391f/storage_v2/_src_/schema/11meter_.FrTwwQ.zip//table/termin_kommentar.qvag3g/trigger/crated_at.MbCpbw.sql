create definer = x2@`%` trigger crated_at
  before INSERT
  on termin_kommentar
  for each row
  SET NEW.created_at = NOW();

