create definer = x2@`%` trigger fulldate_trigger
  before INSERT
  on termine
  for each row
  SET NEW.fulldate = CONCAT(NEW.datum, " ", NEW.treff);

