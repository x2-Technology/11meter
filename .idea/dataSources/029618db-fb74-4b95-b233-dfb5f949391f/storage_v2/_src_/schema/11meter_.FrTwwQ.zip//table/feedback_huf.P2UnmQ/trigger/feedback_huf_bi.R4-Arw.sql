create definer = x2@`%` trigger feedback_huf_bi
  before INSERT
  on feedback_huf
  for each row
BEGIN
    SET NEW.created_at = NOW();
  END;

