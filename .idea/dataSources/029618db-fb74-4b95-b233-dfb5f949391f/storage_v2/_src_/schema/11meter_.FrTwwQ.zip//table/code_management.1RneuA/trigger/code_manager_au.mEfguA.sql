create definer = x2@`%` trigger code_manager_au
  before UPDATE
  on code_management
  for each row
begin
      IF( NEW.started_at IS NOT NULL AND OLD.until_at IS NULL ) THEN
        SET NEW.until_at = DATE_ADD(NEW.started_at, INTERVAL (SELECT validate FROM code_groups WHERE code_groups.id=NEW._code_group) MONTH );
      END IF;

    end;

