create definer = x2@`%` trigger up__2_copy
  before INSERT
  on kontakt
  for each row
BEGIN
DECLARE fullname VARCHAR(64);

SET fullname = CONCAT(NEW.rufname, ' ', NEW.nachname);

IF (NEW.rufname IS NULL) THEN
SET fullname = CONCAT(NEW.vorname, ' ', NEW.nachname);
END IF;


SET NEW.final_name=fullname;

END;

