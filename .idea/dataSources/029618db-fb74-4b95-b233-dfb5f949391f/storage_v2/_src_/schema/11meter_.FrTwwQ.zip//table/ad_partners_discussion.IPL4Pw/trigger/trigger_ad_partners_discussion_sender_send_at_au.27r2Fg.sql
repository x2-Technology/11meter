create definer = x2@`%` trigger trigger_ad_partners_discussion_sender_send_at_au
  before UPDATE
  on ad_partners_discussion
  for each row
BEGIN
  IF(NEW.receiver_answer_text IS NOT NULL )THEN
    SET NEW.receiver_read_at  = NOW();
  end if;
end;

