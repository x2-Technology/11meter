create definer = x2@`%` trigger module_bi
  before INSERT
  on modules
  for each row
  SET NEW.created_at = NOW();

