create definer = x2@`%` trigger delete_denied_for_super_admin_copy
  before DELETE
  on kontakt
  for each row
BEGIN
IF (OLD.user_role='sadmin' ) THEN
SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'Delete operation denied for Super Admin'; 
END IF;
END;

