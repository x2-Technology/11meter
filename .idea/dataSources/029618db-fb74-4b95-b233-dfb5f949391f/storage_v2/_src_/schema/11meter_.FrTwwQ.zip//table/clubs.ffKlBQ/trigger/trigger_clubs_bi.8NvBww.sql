create definer = x2@`%` trigger trigger_clubs_bi
  before INSERT
  on clubs
  for each row
BEGIN
    SET NEW.created_at=NOW();
  end;

