create definer = x2@`%` trigger user_menu_b_update
  before UPDATE
  on user_menu
  for each row
BEGIN
#ACCESS DENIED FOR SAMPLE MENU
IF ( OLD.sample =2 ) THEN
SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'Sample menu is Protected can not update';  
END IF;
/*ACCESS DENIED ACTIVITY FOR BOTTOM MENU*/
IF (  NEW.menu_group=1 AND NEW.activity IS NOT NULL ) THEN
SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'Bottom menu can not have Activity (Please set NULL activity for Buttom menu)';  
END IF;
END;

