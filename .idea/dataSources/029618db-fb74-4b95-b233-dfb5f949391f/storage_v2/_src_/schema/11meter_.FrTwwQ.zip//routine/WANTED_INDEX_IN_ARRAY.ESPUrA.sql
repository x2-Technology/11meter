create
  definer = `11meter`@`%` function WANTED_INDEX_IN_ARRAY(_source json, wanted varchar(255)) returns int
BEGIN

    DECLARE i INT DEFAULT 0;
    DECLARE json_item VARCHAR(255) DEFAULT '';
    DECLARE found_index INT(11) DEFAULT -1;
    WHILE ( i < JSON_LENGTH( _source ) ) DO
        SET json_item = JSON_EXTRACT( _source, CONCAT('$[', i, ']'));
        IF( CONVERT(wanted, CHAR) = CONVERT(json_item, CHAR ) ) THEN
          SET found_index = i;
        end if;
        SET i = i +1;
    END WHILE;

    RETURN found_index;

END;

