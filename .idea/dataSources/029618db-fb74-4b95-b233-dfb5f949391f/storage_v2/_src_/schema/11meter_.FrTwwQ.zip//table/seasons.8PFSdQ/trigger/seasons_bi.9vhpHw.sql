create definer = x2@`%` trigger seasons_bi
  before INSERT
  on seasons
  for each row
  SET NEW.created_at=NOW();

