create definer = x2@`%` trigger up___copy
  after UPDATE
  on kontakt
  for each row
BEGIN
DECLARE fullname VARCHAR(64);

SET fullname = CONCAT(NEW.rufname, ' ', NEW.nachname);

IF (NEW.rufname IS NULL) THEN
SET fullname = CONCAT(NEW.vorname, ' ', NEW.nachname);
END IF;

UPDATE anwesenheit SET sortname=fullname, teamrolle=NEW.teamrolle WHERE kontakt=NEW.id;

END;

