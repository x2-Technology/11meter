create definer = x2@`%` trigger dfb_leagues_b_insert
  before INSERT
  on dfb_leagues
  for each row
  SET NEW.created_at=NOW();

