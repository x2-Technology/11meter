create
  definer = dfb@`%` procedure RESET_NOT_COMPLETED_CLUBS()
BEGIN

    UPDATE dfb_league_clubs SET
                ticket = NULL,
                user_id = NULL,
                completed = NULL,
                begin_update = NULL,
                end_update = NULL,
                process_expired_time = NULL
    WHERE completed IS NULL AND process_expired_time IS NOT NULL AND NOW() > process_expired_time;

          END;

