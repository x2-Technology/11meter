create definer = x2@`%` trigger user_paid_before_insert
  before INSERT
  on user_paid
  for each row
  SET NEW.created_at=NOW();

