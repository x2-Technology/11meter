create
  definer = dfb@`%` function DFB_STATISTICS_2B() returns text
BEGIN

  DECLARE group_id INT DEFAULT 1;
  DECLARE total_league_groups INT DEFAULT 0;
  DECLARE report_json TEXT DEFAULT '{}';

  SELECT COUNT(id)
  FROM league_groups INTO total_league_groups;

  SELECT JSON_INSERT(report_json, '$.total_groups', total_league_groups) INTO report_json;


  SELECT JSON_INSERT(report_json, '$.currently_work_area', (SELECT association_id
                                                            FROM dfb_league_clubs
                                                            WHERE ticket IS NOT NULL
                                                            ORDER BY id DESC
                                                            LIMIT 1)) INTO report_json;
  SELECT JSON_INSERT(report_json, '$.currently_work_area_name', (SELECT gebiet
                                                                 FROM dfb_leagues
                                                                 WHERE id = (SELECT association_id
                                                                             FROM dfb_league_clubs
                                                                             WHERE ticket IS NOT NULL
                                                                             ORDER BY id DESC
                                                                             LIMIT 1))) INTO report_json;







  WHILE group_id <= total_league_groups DO


      SET @current_group_name = (SELECT name FROM league_groups WHERE id = group_id);

      SET @dfb_league_clubs   = CONVERT((SELECT
                                           CONCAT('{
                             "total_club_in_group":"',COUNT(id),'",
                             "current_group_completed_clubs":"', SUM(CASE WHEN completed = 1 THEN 1 ELSE 0 END), '",
                             "group_missing_page":"', SUM(CASE WHEN (to_facebook = 1 OR rating_no_page = 1) AND completed = 1 THEN 1 ELSE 0 END), '"
                             }')

                                          FROM dfb_league_clubs
                                          WHERE league_group_id = group_id) USING UTF8MB4 ) ;

      SET @total_club_in_group            = (SELECT JSON_UNQUOTE(JSON_EXTRACT(@dfb_league_clubs, '$.total_club_in_group')));
      SET @current_group_completed_clubs  = (SELECT JSON_UNQUOTE(JSON_EXTRACT(@dfb_league_clubs, '$.current_group_completed_clubs')));
      SET @group_missing_page             = (SELECT JSON_UNQUOTE(JSON_EXTRACT(@dfb_league_clubs, '$.group_missing_page')));


      SET @working_group_id               = IF( @total_club_in_group > @current_group_completed_clubs, group_id, 0 );
      SET @working_association_name       = (SELECT name FROM associations WHERE id=@working_group_id);
      SET @current_group_completed        = IF( @total_club_in_group = @current_group_completed_clubs, TRUE, FALSE );

      SET @association_id                 = (SELECT association_id FROM dfb_league_clubs WHERE league_group_id = group_id AND completed IS NOT NULL ORDER BY id DESC LIMIT 1);

      SET @associations                       = CONVERT((SELECT CONCAT('{"id":"',id,'","name":"', name, '"}')FROM associations WHERE id= @association_id) USING UTF8MB4 ) ;
      SET @actually_association_in_group_id   = (SELECT (JSON_UNQUOTE(JSON_EXTRACT(@associations, '$.id'))));
      SET @actually_association_in_group_name = (SELECT JSON_EXTRACT(@associations, '$.name'));



      SET @dfb_league_clubs_2 = CONVERT((SELECT
                                          CONCAT('{
                                               "total_association_in_group":"',SUM(CASE WHEN association_id=@actually_association_in_group_id THEN 1 ELSE 0 END ),'",
                                               "completed_association_in_group":"', SUM(CASE WHEN association_id=@actually_association_in_group_id AND completed=1 THEN 1 ELSE 0 END), '",
                                               "worked_time":"', SUM(CASE WHEN worked_time THEN worked_time ELSE 0 END), '"
                                               }')
                                        FROM dfb_league_clubs
                                        WHERE league_group_id = group_id) USING UTF8MB4 ) ;

      SET @total_association_in_group     = (SELECT JSON_EXTRACT(@dfb_league_clubs_2, '$.total_association_in_group'));
      SET @completed_association_in_group = (SELECT JSON_EXTRACT(@dfb_league_clubs_2, '$.completed_association_in_group'));
      SET @worked_time_in_group           = (SELECT JSON_EXTRACT(@dfb_league_clubs_2, '$.worked_time'));


      /*SET @added_contact_in_group         = (SELECT IF( SUM(CASE WHEN email IS NOT NULL THEN 1 WHEN mobil IS NOT NULL THEN 1 ELSE 0 END ) IS NULL, 0 , SUM(CASE WHEN email IS NOT NULL THEN 1 WHEN mobil IS NOT NULL THEN 1 ELSE 0 END )) FROM club_contacts WHERE league_group_id=group_id);
      */
    SET @added_contact_in_group         = (SELECT SUM(CASE WHEN email IS NOT NULL OR mobil IS NOT NULL THEN 1 ELSE 0 END) FROM club_contacts WHERE league_group_id = group_id);






  SET @json_string = CONCAT('{
                "name":"', @current_group_name,'",
                "total_club_in_group":',@total_club_in_group,',
                "current_group_completed_clubs":',@current_group_completed_clubs,',
                "current_group_is_completed":"',(IF(@current_group_completed_clubs = @total_club_in_group, 1, 0 )),'",
                "group_missing_page":',@group_missing_page,',
                "working_group_id":"', @working_group_id,'",
                "actually_association_in_group_id":"', (IF(@actually_association_in_group_id > 0, @actually_association_in_group_id,'')),'",
                "actually_association_in_group_name":"', (IF(@actually_association_in_group_id > 0, JSON_UNQUOTE(@actually_association_in_group_name),'')),'",
                "total_association_in_group":"', JSON_UNQUOTE(@total_association_in_group), '",
                "completed_association_in_group":"',JSON_UNQUOTE( @completed_association_in_group), '",
                "worked_time_in_group":"', JSON_UNQUOTE(@worked_time_in_group), '",
                "added_contact_in_group":"', @added_contact_in_group, '"




              }');




    SELECT JSON_MERGE(report_json, @json_string) INTO report_json;





      SET group_id = group_id + 1;

  end while;


  RETURN report_json;

END;

