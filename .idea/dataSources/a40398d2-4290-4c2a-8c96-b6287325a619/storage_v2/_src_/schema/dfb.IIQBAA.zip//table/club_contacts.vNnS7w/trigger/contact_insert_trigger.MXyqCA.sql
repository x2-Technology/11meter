create definer = x2@`%` trigger contact_insert_trigger
  before INSERT
  on club_contacts
  for each row
  SET NEW.created_at=NOW();

