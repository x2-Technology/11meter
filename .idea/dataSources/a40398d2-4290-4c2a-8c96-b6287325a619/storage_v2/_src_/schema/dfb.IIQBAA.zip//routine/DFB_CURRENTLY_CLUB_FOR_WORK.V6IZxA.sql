create
  definer = dfb@`%` function DFB_CURRENTLY_CLUB_FOR_WORK(uid int) returns text
BEGIN

  DECLARE group_id INT DEFAULT 1;
  DECLARE total_league_groups INT DEFAULT 0;
  DECLARE available_club_id_for_work INT DEFAULT 0;
  DECLARE found_work_group_id INT DEFAULT 0;
  DECLARE group_completed INT DEFAULT 0;
  DECLARE output TEXT DEFAULT '{}';

  SELECT COUNT(id) FROM league_groups INTO total_league_groups;

  myEach : WHILE group_id <= total_league_groups DO

  SET @total_club_in_group            = (SELECT COUNT(id) FROM dfb_league_clubs WHERE league_group_id = group_id);
  SET @current_group_completed_clubs  = (SELECT COUNT(id) FROM dfb_league_clubs WHERE completed IS NOT NULL AND league_group_id = group_id );


  if( @total_club_in_group > @current_group_completed_clubs ) THEN

    SET found_work_group_id = group_id;

    SELECT JSON_INSERT(output, '$.currently_work_group', found_work_group_id ) INTO output;


  end if;

  SET group_completed = 0;
  if( @total_club_in_group = @current_group_completed_clubs ) THEN

    SET group_completed = 1;

  end if;
  SELECT JSON_INSERT(output, '$.currently_group_completed', group_completed ) INTO output;

  if( found_work_group_id <> 0 ) THEN

    IF( uid IS NULL ) THEN

      SET available_club_id_for_work = ( SELECT
                                           id
                                         FROM dfb_league_clubs
                                         WHERE
                                           ( dfb_league_clubs.league_group_id = found_work_group_id AND completed IS NULL AND ticket IS NULL )
                                         ORDER BY id ASC LIMIT 1);

      ELSE

        SET available_club_id_for_work = ( SELECT
                                             id
                                           FROM dfb_league_clubs
                                           WHERE
                                             ( dfb_league_clubs.league_group_id = found_work_group_id AND completed IS NULL AND ticket IS NOT NULL AND user_id = uid ) OR
                                             ( dfb_league_clubs.league_group_id = found_work_group_id AND completed IS NULL AND ticket IS NULL )

                                           ORDER BY id ASC LIMIT 1);


    END IF;



    SELECT JSON_INSERT(output, '$.next_club_for_work', available_club_id_for_work ) INTO output;

    #LEAVE myEach;
  end if;



  SET group_id = group_id + 1;


  END WHILE myEach;

  RETURN output;

END;

