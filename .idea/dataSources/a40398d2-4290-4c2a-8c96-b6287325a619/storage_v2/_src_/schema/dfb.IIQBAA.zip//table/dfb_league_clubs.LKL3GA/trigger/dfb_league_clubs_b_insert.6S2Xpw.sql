create definer = x2@`%` trigger dfb_league_clubs_b_insert
  before INSERT
  on dfb_league_clubs
  for each row
  SET NEW.created_at=NOW();

