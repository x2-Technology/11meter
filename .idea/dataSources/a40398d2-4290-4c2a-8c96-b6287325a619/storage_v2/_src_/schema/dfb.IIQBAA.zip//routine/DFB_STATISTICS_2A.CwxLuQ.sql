create
  definer = dfb@`%` function DFB_STATISTICS_2A() returns text
BEGIN

  DECLARE group_id INT DEFAULT 1;
  DECLARE total_league_groups INT DEFAULT 0;
  DECLARE report_json TEXT DEFAULT '{}';
  DECLARE currently_working_group INT DEFAULT 0;


  SELECT COUNT(id) FROM league_groups INTO total_league_groups;

  SELECT JSON_INSERT(report_json, '$.total_groups', total_league_groups ) INTO report_json;



  SELECT JSON_INSERT(report_json, '$.currently_work_area', (SELECT association_id FROM dfb_league_clubs WHERE ticket IS NOT NULL ORDER BY id DESC LIMIT 1)) INTO report_json;
  SELECT JSON_INSERT(report_json, '$.currently_work_area_name', (SELECT gebiet FROM dfb_leagues WHERE id=(SELECT association_id FROM dfb_league_clubs WHERE ticket IS NOT NULL ORDER BY id DESC LIMIT 1))) INTO report_json;


  WHILE group_id <= total_league_groups DO




        SET @current_group_name = ( SELECT name FROM league_groups WHERE id = group_id );

        SET @total_club_in_group            = (SELECT COUNT(id) FROM dfb_league_clubs WHERE league_group_id = group_id);
        SET @current_group_completed_clubs  = (SELECT COUNT(id) FROM dfb_league_clubs WHERE completed IS NOT NULL AND league_group_id = group_id );
        SET @group_missing_page             = (SELECT COUNT(id) FROM dfb_league_clubs WHERE league_group_id = group_id AND (to_facebook=1 OR rating_no_page=1) AND completed=1);

        SET @added_contact_in_group         = (SELECT COUNT(id) FROM club_contacts WHERE league_group_id = group_id );

        SET @working_group_id         = IF( @total_club_in_group > @current_group_completed_clubs, group_id, 0 );
        SET @working_association_name = (SELECT name FROM associations WHERE id=@working_group_id);
        SET @current_group_completed  = IF( @total_club_in_group = @current_group_completed_clubs, TRUE, FALSE );



        SET @actually_association_in_group_id = ( SELECT id from associations WHERE id=(SELECT association_id FROM dfb_league_clubs WHERE league_group_id = group_id AND completed IS NOT NULL ORDER BY id DESC LIMIT 1));
        SET @actually_association_in_group_name = ( SELECT name from associations WHERE id=(SELECT association_id FROM dfb_league_clubs WHERE league_group_id = group_id AND completed IS NOT NULL ORDER BY id DESC LIMIT 1));

        SET @total_association_in_group = ( SELECT COUNT(id) FROM dfb_league_clubs WHERE league_group_id = group_id AND association_id=@actually_association_in_group_id );
        SET @completed_association_in_group = ( SELECT COUNT(id) FROM dfb_league_clubs WHERE league_group_id = group_id AND association_id=@actually_association_in_group_id AND completed=1 );

        SET @worked_time_in_group    = (SELECT SUM(worked_time) FROM dfb_league_clubs WHERE league_group_id = group_id AND worked_time);

        SET @group_start_date    = (SELECT begin_update FROM dfb_league_clubs WHERE league_group_id=group_id ORDER BY id ASC LIMIT 1);
        SET @group_end_date      = (SELECT end_update FROM dfb_league_clubs WHERE league_group_id=group_id AND completed=1 ORDER BY id DESC LIMIT 1);







        SET @json_string = CONCAT(
            '{
                "name":"', @current_group_name,'",
                "total_club_in_group":"', @total_club_in_group,'",
                "current_group_completed_clubs":"', @current_group_completed_clubs,'",
                "group_missing_page":"', @group_missing_page,'",
                "added_contact_in_group":"', @added_contact_in_group,'",
                "working_group_id":"', @working_group_id,'",
                "current_group_completed":"', @current_group_completed,'",
                "actually_association_in_group_id":"', (IF(@actually_association_in_group_id > 0, @actually_association_in_group_id, '')),'",
                "actually_association_in_group_name":"', (IF(@actually_association_in_group_id > 0, @actually_association_in_group_name, '')),'",
                "total_association_in_group":"', @total_association_in_group, '",
                "completed_association_in_group":"', @completed_association_in_group, '",
                "working_association_name":"', @working_association_name,'",
                "worked_time_in_group":"', (IF(@worked_time_in_group > 0, @worked_time_in_group, 0)),'"
                }'
          );



        SELECT JSON_MERGE(report_json, @json_string) INTO report_json;



        SET group_id = group_id + 1;


  END WHILE;

  /*SELECT JSON_INSERT(report_json, '$.leagues', completed_areas) INTO report_json;*/

  /*SET @current_area_completed = (SELECT COUNT(id) FROM dfb_league_clubs WHERE association_id=1);*/

  RETURN report_json;

END;

