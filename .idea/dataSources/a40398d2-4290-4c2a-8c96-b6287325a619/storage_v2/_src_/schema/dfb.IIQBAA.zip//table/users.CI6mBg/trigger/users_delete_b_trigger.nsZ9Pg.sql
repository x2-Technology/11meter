create definer = x2@`%` trigger users_delete_b_trigger
  before DELETE
  on users
  for each row
BEGIN
IF (OLD.user_role=1 ) THEN
SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'Delete operation denied for Super Admin'; 
END IF;
END;

