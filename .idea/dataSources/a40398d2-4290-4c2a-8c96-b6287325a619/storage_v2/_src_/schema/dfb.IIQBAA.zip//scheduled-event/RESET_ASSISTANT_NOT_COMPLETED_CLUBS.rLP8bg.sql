create definer = dfb@`%` event RESET_ASSISTANT_NOT_COMPLETED_CLUBS on schedule
  every '1' HOUR
    starts '2019-01-24 12:43:21'
  enable
  do
  BEGIN
    CALL RESET_NOT_COMPLETED_CLUBS();
  end;

