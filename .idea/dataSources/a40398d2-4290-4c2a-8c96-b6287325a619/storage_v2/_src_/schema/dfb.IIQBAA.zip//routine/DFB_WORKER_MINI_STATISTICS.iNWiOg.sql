create
  definer = dfb@`%` function DFB_WORKER_MINI_STATISTICS(uid int) returns text
BEGIN

  DECLARE price_for_tel DECIMAL(5,3) DEFAULT 0.00;
  DECLARE price_for_mail DECIMAL(5,3) DEFAULT 0.00;
  DECLARE report_json TEXT DEFAULT '{}';/*DECLARE report_json VARCHAR(1000) DEFAULT '{\"total_leagues\":\"0\"}';*/



  SET price_for_tel     = (SELECT price FROM price WHERE name='tel');
  SET price_for_mail    = (SELECT price FROM price WHERE name='mail');


  SELECT JSON_INSERT(report_json, '$.user_id', uid) INTO report_json;
  SELECT JSON_INSERT(report_json, '$.payment_for_tel', TRUNCATE(price_for_tel, 3)) INTO report_json;
  SELECT JSON_INSERT(report_json, '$.payment_for_mail', TRUNCATE(price_for_mail, 3)) INTO report_json;
  SELECT JSON_INSERT(report_json, '$.full_name', (SELECT vorname FROM users WHERE id=uid)) INTO report_json;
  SELECT JSON_INSERT(report_json, '$.last_worked_time', (SELECT last_worked_time FROM users WHERE id=uid)) INTO report_json;
  SELECT JSON_INSERT(report_json, '$.total_worked_time', (SELECT total_worked_time FROM users WHERE id=uid)) INTO report_json;

  SELECT JSON_INSERT(report_json, '$.currently_work_area', (SELECT association_id FROM dfb_league_clubs WHERE ticket IS NOT NULL ORDER BY id DESC LIMIT 1)) INTO report_json;
  SELECT JSON_INSERT(report_json, '$.currently_work_area_name', (SELECT gebiet FROM dfb_leagues WHERE id=(SELECT association_id FROM dfb_league_clubs WHERE ticket IS NOT NULL ORDER BY id DESC LIMIT 1))) INTO report_json;

  SELECT JSON_INSERT(report_json, '$.my_paid', (SELECT SUM(paid) FROM user_paid WHERE for_user=uid)) INTO report_json;

  SELECT JSON_INSERT(report_json, '$.my_completed_clubs', (SELECT COUNT(id) FROM dfb_league_clubs WHERE user_id=uid AND completed=1)) INTO report_json;

  SELECT JSON_INSERT(report_json, '$.my_added_contact_with_combine', (SELECT COUNT(id) FROM club_contacts WHERE user_id=uid AND email IS NOT NULL AND mobil IS NOT NULL)) INTO report_json;
  SELECT JSON_INSERT(report_json, '$.my_added_contact', (SELECT COUNT(id) FROM club_contacts WHERE user_id=uid AND email IS NOT NULL OR mobil IS NOT NULL)) INTO report_json;
  SELECT JSON_INSERT(report_json, '$.my_added_contact_with_mail', (SELECT COUNT(id) FROM club_contacts WHERE user_id=uid AND email IS NOT NULL)) INTO report_json;
  SELECT JSON_INSERT(report_json, '$.my_added_contact_with_tel', (SELECT COUNT(id) FROM club_contacts WHERE user_id=uid AND mobil IS NOT NULL)) INTO report_json;
  SELECT JSON_INSERT(report_json, '$.my_added_club_with_mail', (SELECT COUNT(id) FROM dfb_league_clubs WHERE user_id=uid AND completed=1 AND email IS NOT NULL)) INTO report_json;







  RETURN report_json;

END;

