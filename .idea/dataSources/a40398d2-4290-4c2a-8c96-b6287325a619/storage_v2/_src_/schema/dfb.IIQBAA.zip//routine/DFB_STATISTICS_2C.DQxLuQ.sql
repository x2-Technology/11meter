create
  definer = dfb@`%` function DFB_STATISTICS_2C() returns text
BEGIN

  RETURN (SELECT
    name as current_group_name,

    @a := (SELECT
             CONVERT((SELECT
                        CONCAT('{
                             "total_club_in_group":"',COUNT(1),'",
                             "current_group_completed_clubs":"', SUM(CASE WHEN completed = 1 THEN 1 ELSE 0 END), '",
                             "group_missing_page":"', SUM(CASE WHEN (to_facebook = 1 OR rating_no_page = 1) AND completed = 1 THEN 1 ELSE 0 END), '"
                             }')

                      FROM dfb_league_clubs
                      WHERE league_group_id = league_groups.id) USING UTF8MB4 ) ) as virtual_src_1,

    @total_club_in_group := (SELECT JSON_UNQUOTE(JSON_EXTRACT(@a, '$.total_club_in_group'))) as total_club_in_group,
    @current_group_completed_clubs := (SELECT JSON_UNQUOTE(JSON_EXTRACT(@a, '$.current_group_completed_clubs'))) as current_group_completed_clubs,
    @group_missing_page := (SELECT JSON_UNQUOTE(JSON_EXTRACT(@a, '$.group_missing_page'))) as group_missing_page,


    @working_group_id               := IF( @total_club_in_group > @current_group_completed_clubs, league_groups.id, 0 ) as working_group_id,
    @working_association_name       := (SELECT name FROM associations WHERE id=@working_group_id) as working_association_name,
    @current_group_completed        := IF( @total_club_in_group = @current_group_completed_clubs, TRUE, FALSE ) as current_group_completed,


    @association_id                 := (SELECT association_id FROM dfb_league_clubs WHERE league_group_id = league_groups.id AND completed IS NOT NULL ORDER BY id DESC LIMIT 1) as association_id,

    @associations                       := CONVERT((SELECT CONCAT('{"id":"',associations.id,'","name":"', associations.name, '"}') FROM associations WHERE id= @association_id) USING UTF8MB4 ) as associations,
    @actually_association_in_group_id   := (SELECT (JSON_UNQUOTE(JSON_EXTRACT(@associations, '$.id')))) as actually_association_in_group_id,
    @actually_association_in_group_name := (SELECT JSON_EXTRACT(@associations, '$.name')) as actually_association_in_group_name,


    @dfb_league_clubs_2 := CONVERT((SELECT
                                      CONCAT('{
                                               "total_association_in_group":"',SUM(CASE WHEN @association_id=@actually_association_in_group_id THEN 1 ELSE 0 END ),'",
                                               "completed_association_in_group":"', SUM(CASE WHEN @association_id=@actually_association_in_group_id AND completed=1 THEN 1 ELSE 0 END), '",
                                               "worked_time":"', SUM(CASE WHEN worked_time THEN worked_time ELSE 0 END), '"
                                               }')
                                    FROM dfb_league_clubs
                                    WHERE league_group_id = league_groups.id) USING UTF8MB4 ) as virtual_src_2,

    (SELECT JSON_EXTRACT(@dfb_league_clubs_2, '$.total_association_in_group')) as total_association_in_group,
    (SELECT JSON_EXTRACT(@dfb_league_clubs_2, '$.completed_association_in_group')) as completed_association_in_group,
    (SELECT JSON_EXTRACT(@dfb_league_clubs_2, '$.worked_time')) as worked_time_in_group,
    (SELECT COUNT(1) FROM club_contacts WHERE league_group_id = league_groups.id) as added_contact_in_group


  FROM league_groups GROUP BY id);

  

END;

