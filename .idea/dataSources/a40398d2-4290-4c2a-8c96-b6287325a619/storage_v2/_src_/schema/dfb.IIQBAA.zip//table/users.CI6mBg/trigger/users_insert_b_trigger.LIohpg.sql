create definer = x2@`%` trigger users_insert_b_trigger
  before INSERT
  on users
  for each row
BEGIN
DECLARE fullname VARCHAR(64);

SET fullname = CONCAT(NEW.vorname, ' ', NEW.nachname);
SET NEW.final_name=fullname;
SET NEW.created_at=NOW();

END;

